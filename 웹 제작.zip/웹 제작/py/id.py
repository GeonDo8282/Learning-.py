from flask import Flask, request, render_template, redirect, url_for
import json
import os

app = Flask(__name__)

BLACKLIST_FILE = "blacklist.json"

def load_blacklist():
    if not os.path.exists(BLACKLIST_FILE):
        return []
    with open(BLACKLIST_FILE, "r", encoding="utf-8") as f:
        data = json.load(f)
        return data.get("blocked_uids", [])

@app.route("/store")
def store():
    uid = request.args.get("uid")  # URL에서 uid 받기

    if not uid:
        return "❌ UID가 없습니다", 400

    blocked_uids = load_blacklist()

    if uid in blocked_uids:
        return redirect(url_for("blocked"))

    return render_template("store.html", uid=uid)

@app.route("/blocked")
def blocked():
    return render_template("blocked.html")

if __name__ == "__main__":
    app.run(debug=True)
