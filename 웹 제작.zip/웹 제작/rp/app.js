import { initializeApp } from "https://www.gstatic.com/firebasejs/11.6.1/firebase-app.js";
import { getAuth, signInAnonymously, onAuthStateChanged } from "https://www.gstatic.com/firebasejs/11.6.1/firebase-auth.js";
import { getFirestore, collection, onSnapshot, addDoc, deleteDoc, doc, serverTimestamp } from "https://www.gstatic.com/firebasejs/11.6.1/firebase-firestore.js";

// Firebase Config
const firebaseConfig = {
  apiKey: "AIzaSyB22JON1sbnBAa5M7-npUbQMgBl5FyhtW0",
  authDomain: "roplace-3109f.firebaseapp.com",
  projectId: "roplace-3109f",
  storageBucket: "roplace-3109f.appspot.com",
  messagingSenderId: "1040522496130",
  appId: "1:1040522496130:web:f061bf198662c25d72cc9b"
};

// App Init
const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const db = getFirestore(app);

let user = null;
let isAdmin = false;
let rpData = [];
let pendingData = [];
const appId = 'roplace-unique-id';

onAuthStateChanged(auth, u => {
  user = u;
  if(user) setupListeners();
});

signInAnonymously(auth).catch(console.error);

function setupListeners() {
  const liveRef = collection(db, 'artifacts', appId, 'public', 'data', 'servers');
  onSnapshot(liveRef, snapshot => {
    rpData = snapshot.docs.map(d => ({id: d.id, ...d.data()}));
    renderMain();
    if(isAdmin) renderAdmin();
  });

  const pendingRef = collection(db, 'artifacts', appId, 'public', 'data', 'pending');
  onSnapshot(pendingRef, snapshot => {
    pendingData = snapshot.docs.map(d => ({id: d.id, ...d.data()}));
    if(isAdmin) renderAdmin();
  });
}

// --- Admin UI ---
window.approveServer = async id => {
  const p = pendingData.find(x=>x.id===id);
  if(!p) return;
  const liveData = {...p, approvedAt: serverTimestamp()};
  delete liveData.id;
  await addDoc(collection(db,'artifacts',appId,'public','data','servers'), liveData);
  await deleteDoc(doc(db,'artifacts',appId,'public','data','pending',id));
};

window.rejectServer = async id => {
  if(confirm("거절하시겠습니까?")) await deleteDoc(doc(db,'artifacts',appId,'public','data','pending',id));
};

window.deleteServer = async id => {
  if(confirm("삭제하시겠습니까?")) await deleteDoc(doc(db,'artifacts',appId,'public','data','servers',id));
};

applyForm.querySelector('button').disabled = true; // 초기 비활성화

onAuthStateChanged(auth, (userData) => {
    user = userData;
    if (user) {
        setupListeners();
        applyForm.querySelector('button').disabled = false; // 인증 완료 후 활성화
    }
});


// --- Render ---
function renderMain() {
  const list = document.getElementById('featured-list');
  list.innerHTML = rpData.map(r => `
    <div class="rp-card flex flex-col h-full rounded-sm overflow-hidden">
      <div class="h-48 bg-zinc-900 relative">
        <img src="${r.image}" class="w-full h-full object-cover" onerror="this.src='https://via.placeholder.com/400x200?text=No+Banner'">
      </div>
      <div class="p-6 flex flex-col flex-grow bg-zinc-950/50">
        <h4 class="text-xl font-bold text-orange-500 mb-2 uppercase">${r.name}</h4>
        <p class="text-zinc-500 text-xs mb-4 line-clamp-2">${r.tagline}</p>
        <div class="mt-auto pt-4 border-t border-zinc-900 flex justify-between items-center">
          <span class="text-[9px] text-zinc-600 font-bold uppercase tracking-widest">By ${r.owner}</span>
          <a href="${r.link}" target="_blank" class="text-[10px] font-black uppercase text-orange-500 hover:text-white transition">Visit →</a>
        </div>
      </div>
    </div>
  `).join('') || '<p class="col-span-full text-center text-zinc-700 py-20 font-bold uppercase tracking-widest">No servers yet.</p>';
}

window.renderAdmin = () => {
  const q = document.getElementById('admin-queue');
  const inv = document.getElementById('admin-inventory');
  q.innerHTML = pendingData.map(p=>`
    <div class="bg-zinc-900 p-4 border border-zinc-800 flex justify-between items-center">
      <div><p class="text-sm font-bold text-white">${p.name}</p><p class="text-[10px] text-zinc-500">${p.owner}</p></div>
      <div class="flex gap-3">
        <button onclick="approveServer('${p.id}')" class="text-orange-500">Approve</button>
        <button onclick="rejectServer('${p.id}')" class="text-zinc-700 hover:text-red-500">Reject</button>
      </div>
    </div>
  `).join('') || '<p class="text-zinc-800 text-xs text-center py-4">No pending</p>';

  inv.innerHTML = rpData.map(r=>`
    <div class="bg-zinc-900/30 p-4 border border-zinc-900 flex justify-between items-center group">
      <div>
        <p class="text-sm font-bold text-zinc-400 group-hover:text-white">${r.name}</p>
        <p class="text-[9px] text-zinc-600">${r.owner}</p>
      </div>
      <button onclick="deleteServer('${r.id}')" class="text-zinc-800 hover:text-red-500">Delete</button>
    </div>
  `).join('') || '<p class="text-zinc-800 text-xs text-center py-4">No live servers</p>';
};
