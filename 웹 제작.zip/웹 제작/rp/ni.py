from flask import Flask, request, jsonify
import json
import datetime
import os

app = Flask(__name__)
LOG_FILE = "log.json"

@app.route("/submit-rp", methods=["POST"])
def submit_rp():
    """
    RP 운영자의 신청 데이터를 수신하여 log.json에 저장합니다.
    """
    try:
        data = request.json
        # 필수 필드 확인
        required_fields = ["rp_name", "rp_link", "description", "image", "operator", "email", "reason"]
        for field in required_fields:
            if field not in data or not data[field]:
                return jsonify({"status": "error", "message": f"Missing field: {field}"}), 400

        # 서버 수신 시간 기록
        data["submitted_at"] = datetime.datetime.now().strftime("%Y-%m-%d %H:%M")

        logs = []
        # 기존 로그 읽기
        if os.path.exists(LOG_FILE):
            try:
                with open(LOG_FILE, "r", encoding="utf-8") as f:
                    logs = json.load(f)
            except json.JSONDecodeError:
                logs = []

        # 새 데이터 추가
        logs.append(data)

        # 로그 파일 업데이트
        with open(LOG_FILE, "w", encoding="utf-8") as f:
            json.dump(logs, f, ensure_ascii=False, indent=2)

        return jsonify({"status": "ok", "message": "Successfully submitted"})
    
    except Exception as e:
        print(f"Error occurred: {e}")
        return jsonify({"status": "error", "message": "Internal Server Error"}), 500

if __name__ == "__main__":
    # 로컬 테스트용 실행 설정
    app.run(debug=True, port=5000)