/**
 * Glow Box Group Official Website Script
 * Handles scrolling effects and interactions.
 */

document.addEventListener('DOMContentLoaded', () => {
    
    // 1. 네비게이션 스크롤 효과
    const nav = document.getElementById('main-nav');
    
    window.addEventListener('scroll', () => {
        if (window.scrollY > 50) {
            nav.classList.add('py-2', 'shadow-md');
            nav.classList.remove('py-4');
        } else {
            nav.classList.remove('py-2', 'shadow-md');
            nav.classList.add('py-4');
        }
        
        // 스크롤 시 요소 나타나기 효과 실행
        revealOnScroll();
    });

    // 2. 스크롤 시 요소 나타나기 애니메이션 (Scroll Reveal)
    function revealOnScroll() {
        const reveals = document.querySelectorAll('.reveal');
        
        reveals.forEach(element => {
            const windowHeight = window.innerHeight;
            const elementTop = element.getBoundingClientRect().top;
            const elementVisible = 150; // 나타날 지점 설정
            
            if (elementTop < windowHeight - elementVisible) {
                element.classList.add('active');
            }
        });
    }

    // 3. 부드러운 스크롤 이동 (IE 지원 및 세밀한 제어)
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            e.preventDefault();
            const target = document.querySelector(this.getAttribute('href'));
            
            if (target) {
                window.scrollTo({
                    top: target.offsetTop - 80, // 네비게이션 높이만큼 오프셋
                    behavior: 'smooth'
                });
            }
        });
    });

    // 초기 실행
    revealOnScroll();
});