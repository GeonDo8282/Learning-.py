import uuid
import json
import os

FILE_NAME = "users.json"

# 유저 데이터 불러오기
def load_users():
    if not os.path.exists(FILE_NAME):
        return []
    with open(FILE_NAME, "r", encoding="utf-8") as f:
        return json.load(f)

# 유저 데이터 저장
def save_users(users):
    with open(FILE_NAME, "w", encoding="utf-8") as f:
        json.dump(users, f, ensure_ascii=False, indent=2)

# 유저 생성
def create_user(name, email):
    users = load_users()

    user = {
        "uid": str(uuid.uuid4()),  # 고유번호 생성
        "name": name,
        "email": email
    }

    users.append(user)
    save_users(users)

    return user["uid"]

# ===================== 실행 =====================
if __name__ == "__main__":
    name = input("이름을 입력하세요: ")
    email = input("이메일을 입력하세요: ")

    uid = create_user(name, email)
    print(f"\n✅ 회원가입 완료!")
    print(f"당신의 고유번호(UID): {uid}")
