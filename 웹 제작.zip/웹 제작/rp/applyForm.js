applyForm.addEventListener('submit', async (e) => {
    e.preventDefault();

    const name = document.getElementById('form-name').value;
    const owner = document.getElementById('form-owner').value;
    const tagline = document.getElementById('form-tagline').value;
    const description = document.getElementById('form-description').value;

    // 금칙어 검사
    if (
        containsForbiddenWord(name) ||
        containsForbiddenWord(owner) ||
        containsForbiddenWord(tagline) ||
        containsForbiddenWord(description)
    ) {
        alert("신청서에 금지된 단어가 포함되어 있습니다. 확인 후 다시 작성해주세요.");
        return;
    }

    // 기존 제출 로직
    try {
        const data = {
            name, owner, tagline, description,
            link: document.getElementById('form-link').value,
            image: document.getElementById('form-image').value,
            createdAt: serverTimestamp(),
            is_featured: false
        };
        await addDoc(collection(db, 'artifacts', appId, 'public', 'data', 'pending'), data);
        alert("신청서가 제출되었습니다. 검토 후 등록됩니다.");
        applyForm.reset();
        showSection('main');
    } catch (err) {
        console.error(err);
        alert("저장 오류가 발생했습니다.");
    }
});
function containsForbiddenWord(text) {
    const lowerText = text.toLowerCase(); // 대소문자 구분 없이 체크
    return forbiddenWords.some(word => lowerText.includes(word));
}
const forbiddenWords = ["욕설1", "욕설2", "금지어1", "금지어2"];

// --- Form 제출 방지 기본 설정 ---
document.addEventListener('DOMContentLoaded', () => {
    const form = document.getElementById('applyForm');
    form.addEventListener('submit', e => {
        e.preventDefault();
        // 처리 로직
    });
});

import { collection, onSnapshot } from "firebase/firestore";

const liveRef = collection(db, 'artifacts', appId, 'public', 'data', 'servers');
onSnapshot(liveRef, (snapshot) => {
  const servers = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
  renderMain(servers); // HTML에 실시간 반영
});

// --- 초기 데이터 (DB 대용) ---
let rpData = JSON.parse(localStorage.getItem('roplace_db_v4')) || [];
let pendingData = JSON.parse(localStorage.getItem('roplace_pending_v4')) || [];
let isAdmin = false;
let currentFilter = 'all';

// --- 유틸리티 ---
function showToast(msg) {
    const container = document.getElementById('toast-container');
    const toast = document.createElement('div');
    toast.className = 'toast';
    toast.innerHTML = `<span class="text-[10px] font-black uppercase tracking-widest">${msg}</span>`;
    container.appendChild(toast);
    setTimeout(() => {
        toast.style.opacity = '0';
        setTimeout(() => toast.remove(), 300);
    }, 3000);
}

function triggerLoader(callback) {
    const loader = document.getElementById('page-loader');
    loader.style.width = '0%';
    loader.style.opacity = '1';
    
    setTimeout(() => loader.style.width = '40%', 50);
    setTimeout(() => loader.style.width = '80%', 200);
    setTimeout(() => {
        loader.style.width = '100%';
        setTimeout(() => {
            loader.style.opacity = '0';
            if (callback) callback();
        }, 200);
    }, 500);
}

function saveToLocal() {
    localStorage.setItem('roplace_db_v4', JSON.stringify(rpData));
    localStorage.setItem('roplace_pending_v4', JSON.stringify(pendingData));
}

// --- Form 제출 처리 (Pending 추가) ---
document.getElementById('applyForm').addEventListener('submit', function(e) {
    e.preventDefault();

    const formData = new FormData(this);
    const newServer = {
        id: Date.now(),
        name: formData.get('name'),
        owner: formData.get('owner'),
        tagline: formData.get('tagline'),
        description: formData.get('description'),
        link: formData.get('link'),
        image: formData.get('image'),
        tags: [],        // 필요하면 추후 입력
        approved: false, // 심사 전
    };

    pendingData.push(newServer);
    saveToLocal();

    renderAdmin();
    showToast('서버 등록 요청이 성공적으로 제출되었습니다!');
    this.reset();
});

// --- Admin UI 업데이트 ---
function renderAdmin() {
    // Pending Sync 카운트
    document.getElementById('count-pending').textContent = pendingData.length;

    // Inbound Requests 목록
    const queue = document.getElementById('admin-queue');
    queue.innerHTML = '';

    pendingData.forEach((srv, idx) => {
        const div = document.createElement('div');
        div.className = 'bg-zinc-950 p-4 rounded-sm border border-white/5 flex justify-between items-center';
        div.innerHTML = `
            <span class="text-white font-black text-xs">${srv.name} / ${srv.owner}</span>
            <div class="flex gap-2">
                <button onclick="approveServer(${idx})" class="bg-orange-500 px-4 py-1 text-[10px] font-black uppercase rounded-sm hover:bg-white hover:text-black transition">Approve</button>
                <button onclick="rejectServer(${idx})" class="bg-red-600 px-4 py-1 text-[10px] font-black uppercase rounded-sm hover:bg-white hover:text-black transition">Reject</button>
            </div>
        `;
        queue.appendChild(div);
    });
}

// --- 서버 승인 ---
function approveServer(idx) {
    const server = pendingData[idx];
    server.approved = true;
    rpData.push(server);

    pendingData.splice(idx, 1);
    saveToLocal();
    renderAdmin();
    showToast(`${server.name} 서버가 승인되었습니다!`);
}

// --- 서버 거절 ---
function rejectServer(idx) {
    const server = pendingData[idx];
    pendingData.splice(idx, 1);
    saveToLocal();
    renderAdmin();
    showToast(`${server.name} 서버가 거절되었습니다.`);
}

// --- 섹션 전환 ---
function showSection(sectionId) {
    triggerLoader(() => {
        document.querySelectorAll('main > div').forEach(div => div.classList.add('hidden'));
        const target = document.getElementById(`section-${sectionId}`);
        if (target) target.classList.remove('hidden');
        window.scrollTo({ top: 0, behavior: 'smooth' });
        if (sectionId === 'admin') renderAdmin();
    });
}

const form = document.getElementById('applyForm');
form.addEventListener('submit', function(e) {
    e.preventDefault(); // 페이지 새로고침 방지

    // 폼 데이터 가져오기
    const formData = new FormData(form);
    const newServer = {
        id: Date.now(),
        name: formData.get('name'),
        owner: formData.get('owner'),
        tagline: formData.get('tagline'),
        description: formData.get('description'),
        link: formData.get('link'),
        image: formData.get('image'),
        tags: [], // 필요하면 태그 추가
        approved: false,
    };

    // Pending 데이터 저장
    pendingData.push(newServer);
    saveToLocal();

    // 어드민 화면에 바로 추가
    if (isAdmin) renderAdmin(); // 이미 어드민 페이지 열려있으면 새로 그려줌

    showToast('서버 신청이 완료되었습니다!');

    form.reset(); // 입력 초기화
});

// --- 초기 Admin 렌더링 ---
if(document.getElementById('section-admin')) renderAdmin();
// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
import { getAnalytics } from "firebase/analytics";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
// For Firebase JS SDK v7.20.0 and later, measurementId is optional
const firebaseConfig = {
  apiKey: "AIzaSyB22JON1sbnBAa5M7-npUbQMgBl5FyhtW0",
  authDomain: "roplace-3109f.firebaseapp.com",
  projectId: "roplace-3109f",
  storageBucket: "roplace-3109f.firebasestorage.app",
  messagingSenderId: "1040522496130",
  appId: "1:1040522496130:web:f061bf198662c25d72cc9b",
  measurementId: "G-WPFNGC1EV9"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const analytics = getAnalytics(app);
// --- 익명 로그인 ---
signInAnonymously(auth)
    .then(() => console.log("Firebase Auth: Signed in anonymously"))
    .catch(err => console.error("Auth error:", err));

onAuthStateChanged(auth, (u) => {
    user = u;
    if(user) {
        console.log("Firebase Auth: User ready", user.uid);
        setupListeners();
    } else {
        console.log("Firebase Auth: Waiting...");
    }
});
// --- Firestore 실시간 리스너 ---
function setupListeners() {
    // Live 서버
    const liveRef = collection(db, 'artifacts', 'roplace-unique-id', 'public', 'data', 'servers');
    onSnapshot(liveRef, snap => {
        rpData = snap.docs.map(d => ({ id: d.id, ...d.data() }));
        document.getElementById('count-live').textContent = rpData.length;
        renderMain();
        if(isAdmin) renderAdmin();
    });

    // Pending 서버
    const pendingRef = collection(db, 'artifacts', 'roplace-unique-id', 'public', 'data', 'pending');
    onSnapshot(pendingRef, snap => {
        pendingData = snap.docs.map(d => ({ id: d.id, ...d.data() }));
        document.getElementById('count-pending').textContent = pendingData.length;
        if(isAdmin) renderAdmin();
    });
}
