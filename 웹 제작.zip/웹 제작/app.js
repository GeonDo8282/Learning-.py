/**
 * Glow Box Official Website JS
 * Business Section 디자인 고도화 및 인터랙션 강화
 */

lucide.createIcons();

// 1. 마우스 글로우 효과
const glow = document.getElementById('cursorGlow');
window.addEventListener('mousemove', (e) => {
    if (glow) {
        glow.style.left = e.clientX + 'px';
        glow.style.top = e.clientY + 'px';
    }
});

// 2. 히어로 타이틀 텍스트 애니메이션
const textArray = [
    "요즘 참 춥죠.<br>그래도 저희는 투명합니다.",
    "상상하는 웹사이트,<br>Glow Box가 현실로.",
    "정직한 프로세스,<br>압도적인 결과물."
];
let textIndex = 0;
const textEl = document.getElementById('heroTitle');

if (textEl) {
    setInterval(() => {
        textEl.style.opacity = 0;
        setTimeout(() => {
            textIndex = (textIndex + 1) % textArray.length;
            textEl.innerHTML = textArray[textIndex];
            textEl.style.opacity = 1;
        }, 400);
    }, 4500);
}

// 3. 블랙리스트 데이터
const blacklistData = [
    { id: "kim_**_92", reason: "최종 검수 후 잔금 미지불 및 연락 두절", status: "영구 차단", date: "2024-01-20" },
    { id: "studio_***_official", reason: "타인 포트폴리오 무단 도용 및 사칭 의뢰", status: "영구 차단", date: "2024-02-05" },
    { id: "user_774**", reason: "상습적인 무상 추가 작업 요구 및 업무 방해", status: "주의", date: "2024-02-18" },
    { id: "dev_buyer_**", reason: "허위 견적서 발행 유도 후 경쟁사 가격 비교 이용", status: "주의", date: "2024-03-01" },
    { id: "anonymous_99", reason: "작업 소스 코드 수령 후 카드 승인 취소(환불 사기)", status: "영구 차단", date: "2024-03-10" }
];

let currentFilterType = 'all';

function renderBlacklist(data = blacklistData) {
    const tbody = document.getElementById('blacklistBody');
    if (!tbody) return;

    tbody.innerHTML = data.map(item => `
        <tr>
            <td><strong>${item.id}</strong></td>
            <td>${item.reason}</td>
            <td><span class="status-badge ${item.status === '영구 차단' ? 'danger' : 'warn'}">${item.status}</span></td>
            <td>${item.date}</td>
        </tr>
    `).join('');
}

window.filterBlacklist = function() {
    const query = document.getElementById('blacklistSearch').value.toLowerCase();
    const filtered = blacklistData.filter(item => {
        const matchesQuery = item.id.toLowerCase().includes(query);
        const matchesType = currentFilterType === 'all' || item.status === currentFilterType;
        return matchesQuery && matchesType;
    });
    renderBlacklist(filtered);
};

window.filterType = function(type) {
    currentFilterType = type;
    document.querySelectorAll('.filter-btn').forEach(btn => {
        btn.classList.remove('active');
        if(btn.innerText === type || (type === 'all' && btn.innerText === '전체')) {
            btn.classList.add('active');
        }
    });
    window.filterBlacklist();
};

// 4. 프로모션 안내
window.showPromoInfo = function() {
    const statusText = document.getElementById('liveStatus');
    statusText.innerText = "🎉 쿠폰: GLOW-WINTER-20 (적용대기)";
    statusText.style.color = "#ff7e5f";
    setTimeout(() => {
        statusText.innerText = "현재 Glow Box 상담 가능";
        statusText.style.color = "inherit";
    }, 5000);
};

// 5. 스크롤 애니메이션
function initScrollReveal() {
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('reveal-active');
            }
        });
    }, { threshold: 0.1 });

    document.querySelectorAll('section, .service-card, .stat-card, .h-badge, .floating-card').forEach(el => {
        el.classList.add('reveal-ready');
        observer.observe(el);
    });
}

window.addEventListener('DOMContentLoaded', () => {
    renderBlacklist();
    initScrollReveal();
    
    const nav = document.querySelector('.glass-nav');
    window.addEventListener('scroll', () => {
        if (!nav) return;
        if (window.scrollY > 50) {
            nav.style.width = '95%';
            nav.style.top = '10px';
        } else {
            nav.style.width = '90%';
            nav.style.top = '20px';
        }
    });
});